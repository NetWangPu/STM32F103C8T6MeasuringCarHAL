#ifndef __ENCODER_H
#define __ENCODER_H

#include "./SYSTEM/sys/sys.h"

void MX_TIM2_Init(void);
uint32_t Get_Value(void);


#endif

















